# 保福山聖教醫館略述十八編

《保福山聖教醫館略述十八編》刊於清光緒年間，記錄福州保福山聖教醫館的病例分類、來診統計、捐輸與院務。卷末列出當時流通的西醫書籍，可供教會醫療史、財務史與出版史比較。

This 1893 annual report from the Baofushan Christian Hospital in Fuzhou records historical patient statistics, hospital accounts, donations, and a list of medical books in circulation.

- 原刊由保福山聖教醫館編纂，1893 年刊於福州。共 30 幅，依底本分幅定位。 [館藏／原件](https://id.lib.harvard.edu/alma/990082560560203941/catalog)

- JSON 保留欄位及各幅來源雜湊。TXT 可連讀，TEI 可供交換與字位掛接。

- 全冊由兩份各自看原圖的 AI 讀稿進行差異比對，回圖裁定並訂正 8 處原欄文字。疑讀與原印差異照實保留。尚待人工全文校對。

- 歷史原刊為公有領域。新撰說明與編碼 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。

- 資料整理者曲宸宇（Chen-Yu Chu）。 [ORCID](https://orcid.org/0009-0003-9738-6914)
